synthetic apps/web/app.js
