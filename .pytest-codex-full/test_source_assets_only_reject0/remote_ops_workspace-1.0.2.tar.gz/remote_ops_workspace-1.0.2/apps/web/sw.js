synthetic apps/web/sw.js
