synthetic sw.js
