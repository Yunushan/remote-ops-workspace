synthetic src/remote_ops_workspace/paths.py
