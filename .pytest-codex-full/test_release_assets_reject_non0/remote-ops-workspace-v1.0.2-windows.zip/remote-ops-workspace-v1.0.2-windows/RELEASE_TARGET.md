synthetic RELEASE_TARGET.md
