synthetic app.js
