synthetic setup.py
